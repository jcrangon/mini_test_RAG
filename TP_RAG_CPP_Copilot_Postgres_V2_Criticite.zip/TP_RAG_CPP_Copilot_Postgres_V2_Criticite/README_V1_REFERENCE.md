# TP — RAG C++ avec Clang, Python, PostgreSQL/pgvector et GitHub Copilot (CLion)

**Public :** developpeurs C++ debutants/intermediaires sur la partie RAG.
**Duree indicative :** 2 a 3 heures hors telechargements.
**Plateforme principale :** Windows 10/11, PowerShell, Docker Desktop, CLion.

## Ce que l'on construit

1. Un depot local C++ est parcouru par Python (sans envoi du depot sur internet).
2. Clang analyse les definitions de fonctions lorsque la configuration de compilation le permet.
3. Python decoupe les fichiers en fragments et calcule des **embeddings localement** avec
   `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` (384 dimensions).
4. PostgreSQL 17 avec l'extension **pgvector** conserve les fragments et leurs vecteurs.
5. Python effectue une recherche de similarite avec pgvector.
6. Un serveur MCP Python expose des outils de recherche en **lecture seule**.
7. **GitHub Copilot dans CLion, en mode Agent**, appelle ce serveur pour recuperer
   les extraits puis redige une reponse en les citant.

**Il n'y a ni Ollama, ni API d'embeddings distante, ni cle API de modele.**
Le telechargement initial du modele necessite un acces internet. Le modele s'execute
ensuite localement. **Attention** : lorsque Copilot utilise un resultat MCP, les
fragments retournes peuvent etre transmis au service GitHub Copilot. Ce montage
n'est pas un dispositif d'inference integralement sur site. Pour l'atelier,
utiliser exclusivement un depot pedagogique non confidentiel.

## Fichiers fournis

```
TP_RAG_CPP_Copilot_Postgres/
|-- docker-compose.yml                # PostgreSQL + pgvector dans Docker
|-- .env.example                     # configuration a copier en .env
|-- requirements.txt                 # librairies Python
|-- rag.py                           # Clang, decoupage, embeddings, PostgreSQL, recherche
|-- mcp_server.py                    # serveur MCP pour GitHub Copilot
|-- copilot-instructions.txt         # consignes a fournir a Copilot
|-- config/
|   `-- copilot_jetbrains_mcp.template.json
|-- examples/cpp_demo/
|   |-- CMakeLists.txt
|   |-- README.md
|   |-- include/cart.hpp
|   `-- src/cart.cpp et src/main.cpp
`-- tests/test_chunker.py
```

## Etape 1 — Installer les outils

A installer sur Windows :

- Docker Desktop, conteneurs Linux actives.
- Python **3.11 ou plus** (avec le lanceur `py`).
- LLVM/Clang (`clang++` accessible dans le PATH). Sur Windows, verifier
  au besoin `C:\Program Files\LLVM\bin` dans les variables d'environnement PATH.
- CLion et **plugin GitHub Copilot** recent, session GitHub ouverte,
  droits d'acces au mode Agent et aux serveurs MCP. Dans une organisation,
  l'administrateur peut devoir activer la politique `MCP servers in Copilot`.

PowerShell :

```powershell
docker --version
docker compose version
py --version
clang++ --version
```

Si `clang++` n'est pas reconnu, installer LLVM, ajouter son dossier `bin`
au PATH et rouvrir le terminal. Si Docker n'est pas pret, demarrer Docker Desktop.

## Etape 2 — Extraire l'archive et ouvrir PowerShell

Decompresser le ZIP puis se placer dans le dossier ou se trouve `docker-compose.yml` :

```powershell
cd C:\dev\TP_RAG_CPP_Copilot_Postgres
```

Le chemin `C:\dev\...` est un exemple ; utiliser le chemin reel sur le poste.

## Etape 3 — Configurer le fichier .env

```powershell
Copy-Item .env.example .env
notepad .env
```

Commencer avec le depot d'exemple :

```dotenv
CPP_REPO=./examples/cpp_demo
POSTGRES_DSN=postgresql://rag:rag_demo_pwd@127.0.0.1:5433/rag_cpp
EMBED_MODEL=sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2
CLANG_BIN=clang++
RAG_TOP_K=5
HF_HUB_DISABLE_TELEMETRY=1
```

Puis, pour le depot des eleves, remplacer `CPP_REPO` par un chemin absolu :

```dotenv
CPP_REPO=C:/dev/mon-depot-cpp
```

**La valeur `CPP_REPO` pointe vers le dossier racine du depot, pas vers un seul fichier.**

## Etape 4 — Lancer la base PostgreSQL dockerisee

```powershell
docker compose up -d
docker compose ps
```

Attendre que le conteneur `tp-rag-cpp-postgres` soit `healthy`.

Verifier PostgreSQL et l'extension :

```powershell
docker compose exec postgres psql -U rag -d rag_cpp -c "CREATE EXTENSION IF NOT EXISTS vector;"
docker compose exec postgres psql -U rag -d rag_cpp -c "SELECT extname, extversion FROM pg_extension WHERE extname='vector';"
```

Connexion locale : `127.0.0.1:5433` ; base `rag_cpp`, utilisateur `rag`.
Le port n'est expose que sur la boucle locale (pas sur l'ensemble du reseau).
**Le mot de passe fourni est un mot de passe de TP, a remplacer pour un usage reel.**

## Etape 5 — Installer Python

Depuis le dossier du TP :

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Le premier telechargement peut etre long : `sentence-transformers` utilise PyTorch.
Ne pas installer Ollama et ne pas configurer de cle API.

## Etape 6 — Verifier le depot et la base

```powershell
.\.venv\Scripts\python.exe rag.py check
```

Attendu : depot existe, `Clang` avec un chemin valide, `PostgreSQL: OK`,
`Fichiers autorises: ...`.

## Etape 7 — Indexer le depot C++

```powershell
.\.venv\Scripts\python.exe rag.py index
```

Au **premier lancement**, Python telecharge le modele d'embeddings depuis Hugging Face.
Les fichiers du depot C++ ne sont pas envoyes au service de modeles pour calculer
les vecteurs : l'inference se fait sur le poste.

L'indexation fait :

1. Liste des fichiers C/C++/Markdown/CMake/TXT sous `CPP_REPO`.
2. Ignore notamment `.git`, `.env`, `build`, `.venv`, `node_modules` et les liens symboliques.
3. Cree des fragments de 50 lignes avec chevauchement de 10 lignes.
4. Tente une extraction structurelle des fonctions C++ via Clang (`-ast-dump=json`, filtres de symboles).
5. Calcule un vecteur de 384 valeurs par fragment.
6. Cree la table `rag_chunks` et l'index HNSW dans PostgreSQL, puis remplace l'ancienne indexation.

Sur le petit depot fourni, l'extraction Clang identifie `clampPercent`, `Cart`, `canMove`,
`recharge`, `batteryLevel` et `main` si Clang peut compiler les fichiers.
Si les dependances CMake d'un vrai depot ne sont pas disponibles, les fragments
par lignes restent indexables, mais le nombre de fonctions extraites via Clang
peut etre zero. Cette version pedagogique **n'interprete pas encore**
`compile_commands.json` : cette amelioration sera un bon exercice.

## Etape 8 — Verifier PostgreSQL

```powershell
.\.venv\Scripts\python.exe rag.py stats
```

Verification SQL directe :

```powershell
docker compose exec postgres psql -U rag -d rag_cpp -c "SELECT file_path, kind, symbol, start_line, end_line FROM rag_chunks ORDER BY file_path, start_line;"
```

Vous devez retrouver notamment `src/cart.cpp`.

## Etape 9 — TESTER LA RECHERCHE SANS COPILOT

```powershell
.\.venv\Scripts\python.exe rag.py search "Dans quelles conditions le chariot peut-il se deplacer ?"
```

Attendu : plusieurs passages du depot, notamment `Cart::canMove` dans
`src/cart.cpp`, affiches avec **chemin, lignes et score de similarite**.

Deuxieme question :

```powershell
.\.venv\Scripts\python.exe rag.py search "Comment la batterie est-elle bornee entre zero et cent ?"
```

Vous devez retrouver `clampPercent`, `Cart::Cart` et/ou `Cart::recharge`.

**Si la recherche ne retrouve pas les bons extraits, il ne sert a rien de tester
Copilot : regler d'abord la partie indexation/recherche.**

## Etape 10 — Exposer la recherche comme outils MCP

Le fichier `mcp_server.py` contient deux outils :

- `etat_rag_cpp` : prouve que le serveur MCP et PostgreSQL sont joignables ;
  il renvoie le marqueur exact `RAG_CPP_MCP_CONNECTE`.
- `rechercher_code_cpp(question, limite)` : envoie la question au moteur
  de recherche local et renvoie jusqu'a 10 extraits avec les references.

Le serveur utilise **stdio** : CLion lance Python et communique avec lui.
**Ne pas demarrer le script manuellement dans un terminal ordinaire en esperant
voir une page Web** ; en attente du protocole MCP, il n'affiche normalement rien.

## Etape 11 — Declarer le serveur MCP dans GitHub Copilot de CLion

Dans CLion :

1. Verifier que le plugin GitHub Copilot est installe et connecte.
2. Ouvrir `GitHub Copilot Chat` et selectionner **Agent**.
3. Cliquer sur l'icone **Tools / Configure your MCP server** puis **Add MCP Tools**.
4. Le fichier `mcp.json` utilise par le plugin s'ouvre.
5. Ajouter l'entree `rag-cpp` a son objet racine `servers`.

**EXEMPLE DE CONFIGURATION** (remplacer les deux chemins absolus) :

```json
{
  "servers": {
    "rag-cpp": {
      "type": "stdio",
      "command": "C:/dev/TP_RAG_CPP_Copilot_Postgres/.venv/Scripts/python.exe",
      "args": [
        "C:/dev/TP_RAG_CPP_Copilot_Postgres/mcp_server.py"
      ]
    }
  }
}
```

Sur Windows, les `/` dans les chemins JSON sont acceptes. Les chemins doivent
correspondre a l'installation sur **le poste de chaque eleve**.

Si le fichier MCP comporte deja d'autres serveurs, **ne pas les effacer** :
ajouter seulement la cle `rag-cpp` a `servers`, avec une virgule entre les objets.

Enregistrer et actualiser/redemarrer le serveur MCP dans la configuration Copilot
si necessaire. Revenir au mode Agent puis ouvrir la liste des outils.

**Important :** ne pas confondre le serveur MCP integre a CLion (qui permet aux
clients externes de commander l'IDE) avec le serveur MCP **rag-cpp** que l'on
branche dans le plugin GitHub Copilot. Ce sont deux fonctionnalites distinctes.

## Etape 12 — PROUVER que Copilot utilise le RAG

Dans Copilot Chat en mode Agent, avec les outils MCP `rag-cpp` autorises,
demander explicitement :

> Appelle l'outil MCP `etat_rag_cpp`. Recopie la valeur `RAG_CPP_MCP_CONNECTE`
> et donne le nombre de fragments indexes. N'utilise pas tes connaissances generales.

La preuve d'une liaison reussie comporte **les trois elements** :

1. La trace visible d'un **appel reel** de l'outil `etat_rag_cpp` dans Copilot.
2. Le marqueur `RAG_CPP_MCP_CONNECTE` retourne par **l'outil**, pas invente par le modele.
3. Le nombre de fragments concordant avec `python rag.py stats`.

Puis demander :

> Appelle imperativement `rechercher_code_cpp` pour trouver les conditions
> d'autorisation de deplacement. Explique la fonction C++ et cite le nom du
> fichier ainsi que les lignes exactes. Si tu ne peux pas appeler l'outil,
> indique explicitement que tu ne peux pas verifier le code.

Verifier dans la trace de Copilot que **rechercher_code_cpp** a ete appele.
Une reponse correcte sans trace d'appel **ne prouve pas** que le RAG a servi :
Copilot pourrait avoir lu directement les fichiers de l'IDE ou hallucine.

Le fichier `copilot-instructions.txt` peut etre copie dans un message initial
au chat pour rappeler les consignes de consultation du RAG.

## Etape 13 — Experience de mise a jour

Modifier dans `examples/cpp_demo/src/cart.cpp` la condition `battery_percent_ >= 20`
en `battery_percent_ >= 35` (**sur le depot d'exemple uniquement**).

Avant une reindexation, la base **contient encore l'ancienne version**.
Executer :

```powershell
.\.venv\Scripts\python.exe rag.py index
```

Redemander a Copilot, avec appel de `rechercher_code_cpp`, le seuil minimal.
La bonne reponse attendue est desormais **35 %**.

**Conclusion :** un RAG indexe n'est pas automatiquement synchronise avec Git.
Il faut un mecanisme de reindexation (manuel dans ce TP, Git hooks/CI ensuite).

## Etape 14 — Tests automatiques

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Les tests couvrent les plages de lignes, les fichiers exclus et les identifiants
reproductibles. Ils n'ont besoin ni de Clang, ni de Docker pour cette partie.

## Etape 15 — Arret / reprise du TP

Arreter le conteneur en conservant les donnees :

```powershell
docker compose down
```

Reprendre :

```powershell
docker compose up -d
.\.venv\Scripts\python.exe rag.py stats
```

**Supprimer la base et l'ensemble des vecteurs (destructif) :**

```powershell
docker compose down -v
```

Ne pas executer `down -v` pour une simple pause.

## Depannage

| Symptome | Cause probable | Action |
|---|---|---|
| `Connection refused` sur 5433 | conteneur arrete | `docker compose up -d`; puis `docker compose ps` |
| `port is already allocated` | port 5433 deja utilise | changer 5433 dans Docker et `POSTGRES_DSN` |
| `clang++` introuvable | LLVM absent du PATH | installer LLVM, ajouter `bin`, rouvrir PowerShell |
| `fonctions_clang: 0` | headers / options de compilation manquants | verifier les includes, utiliser depot d'exemple, puis adapter `compile_commands.json` |
| `No module named ...` | mauvaise installation Python | lancer les commandes depuis `.venv/Scripts/python.exe` |
| Copilot ne voit pas `rag-cpp` | chemin JSON faux ou plugin obsolete | verifier les deux chemins absolus, enregistrer `mcp.json`, controler le mode Agent |
| Copilot repond sans appeler MCP | autres outils ou contexte IDE exploites | exiger l'appel explicite et verifier la trace |
| Embeddings tres lents | inference CPU | limiter la taille du depot, attendre le chargement du modele |
| 0 fragments dans PostgreSQL | indexation non lancee | `python rag.py index` |
| Extraits obsoletes | index non synchronise | relancer `python rag.py index` |

## Limites volontaires de cette version pedagogique

- Indexation globale avec remplacement complet de la table, non incrementale.
- Les fichiers textes sont decoupes par lignes; extraction AST de fonctions en bonus.
- Clang est execute avec `-std=c++17` et les repertoires `repo` / `repo/include` ;
  les projets CMake multi-cibles demanderaient le support de `compile_commands.json`.
- Recherche vectorielle simple, sans reranking hybride, et sans evaluation automatique.
- Aucun mecanisme d'authentification pour un acces reseau car l'acces PostgreSQL
  est limite a localhost et le MCP emploie stdio local.
- Les fichiers exclus par extension, repertoires et taille reduisent l'exposition
  accidentelle ; ce n'est **pas** un scanner de secrets ni une garantie de securite.
- Les extraits rendus a Copilot peuvent quitter la machine : necessite une
  validation des regles d'usage de l'organisation.

## Extensions proposees aux eleves

1. Ajouter l'analyse de `compile_commands.json` et des headers avec Clang.
2. Remplacer le rechargement complet par une mise a jour incrementale basee sur SHA-256.
3. Ajouter une recherche hybride (full-text PostgreSQL + similarite vectorielle).
4. Bloquer l'indexation des fichiers classifies via une liste d'exclusion explicite.
5. Evaluer precision@5 sur un jeu de questions dont les reponses sont connues.
6. Connecter les depot GitLab prives sans donner de privileges GitLab au serveur MCP de lecture.

## Documentation de reference

- GitHub Copilot / MCP / JetBrains :
  https://docs.github.com/en/copilot/how-tos/provide-context/use-mcp-in-your-ide/extend-copilot-chat-with-mcp
- pgvector : https://github.com/pgvector/pgvector
- SDK Python MCP v2 : https://github.com/modelcontextprotocol/python-sdk
- Sentence Transformers :
  https://huggingface.co/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2
