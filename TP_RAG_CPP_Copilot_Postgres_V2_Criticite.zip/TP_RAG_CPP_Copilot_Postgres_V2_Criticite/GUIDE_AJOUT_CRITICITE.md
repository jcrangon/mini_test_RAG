# TP : ajouter des niveaux de criticite au RAG C++ / PostgreSQL / Copilot / CLion

> Cette V2 **met a jour le projet de TP precedent**. Elle conserve PostgreSQL,
> son conteneur, le modele d'embeddings local et l'integration MCP pour Copilot.
> **Pas d'Ollama.** Les seuls niveaux metier autorises sont VERT, ORANGE et ROUGE.
> L'absence de classement est affichee NON_CLASSEE.

## 0. Avant de commencer

Dans PowerShell :

```powershell
cd C:\dev\TP_RAG_CPP_Copilot_Postgres
Get-Content .env
```

Verifier que `CPP_REPO` pointe vers le bon dossier. Pour le depot fourni :

```dotenv
CPP_REPO=./examples/cpp_demo
```

**Sauvegarder ses modifications personnelles** avant de remplacer les fichiers du projet V1.

## 1. Le referentiel se trouve dans le depot C++

Creer `criticality.yaml` **a la racine du depot C++**, et pas a cote de
`rag.py` (sauf si ce sont exactement les memes dossiers).

Pour le depot de demonstration :

```powershell
notepad .\examples\cpp_demo\criticality.yaml
```

Contenu :

```yaml
version: 1
functions:
  - file: "src/cart.cpp"
    symbol: "Cart::canMove"
    level: "ROUGE"
    reason: "Autorise le deplacement du chariot."
    rules:
      - "Conserver le seuil minimal de batterie."
      - "Interdire le mouvement si les freins ne sont pas liberes."
      - "Interdire le mouvement lorsqu'un obstacle est detecte."
    validation:
      - "Tests du seuil et des valeurs limites."
      - "Tests des freins et de la detection d'obstacles."
      - "Relecture par un responsable des fonctions de securite."

  - file: "src/cart.cpp"
    symbol: "Cart::recharge"
    level: "ORANGE"
    reason: "Modifie l'etat de charge de la batterie."
    rules:
      - "Maintenir une charge bornee entre 0 et 100."
    validation:
      - "Tests des bornes et des valeurs invalides."

  - file: "src/cart.cpp"
    symbol: "Cart::batteryLevel"
    level: "VERT"
    reason: "Retourne uniquement le niveau de batterie."
    rules:
      - "Ne pas modifier l'etat du chariot."
    validation:
      - "Tester la valeur retournee."
```

Regles YAML :
- `file` est un chemin relatif a `CPP_REPO`, utilise `/` meme sous Windows.
- `symbol` est le **symbole qualifie Clang**, par exemple `Cart::canMove`.
- `level` est exactement `VERT`, `ORANGE` ou `ROUGE`.
- `reason` est obligatoire ; pour `ROUGE`, `rules` et `validation` doivent etre non vides.
- Les noms de fonctions surchargees ou ambigus ne sont **pas automatiquement classes**.
- Versionner et faire valider ce fichier par les responsables metier/securite.

## 2. Fichiers du projet modifies

| Fichier | Changement |
|---|---|
| `requirements.txt` | Ajout de `PyYAML>=6.0,<7` |
| `criticality.py` | **Nouveau** : lecture YAML, validation, association avec les symboles Clang |
| `rag.py` | Extraction des symboles qualifies, enregistrement des metadonnees, commandes `audit`, `stats`, `search` enrichies |
| `mcp_server.py` | Transmission du niveau, de la raison, des regles et des tests a Copilot |
| `copilot-instructions.txt` | Comportement recommande selon le niveau de criticite |
| `tests/test_criticality.py` | Nouveaux tests de validation YAML, association et surcharge |

Le script `rag.py` ajoute automatiquement les colonnes manquantes a `rag_chunks` :

```sql
ALTER TABLE rag_chunks ADD COLUMN IF NOT EXISTS criticality_level TEXT NOT NULL DEFAULT 'NON_CLASSEE';
ALTER TABLE rag_chunks ADD COLUMN IF NOT EXISTS criticality_scope TEXT NOT NULL DEFAULT 'NON_CLASSEE';
ALTER TABLE rag_chunks ADD COLUMN IF NOT EXISTS criticality_reason TEXT NOT NULL DEFAULT '';
ALTER TABLE rag_chunks ADD COLUMN IF NOT EXISTS criticality_rules JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE rag_chunks ADD COLUMN IF NOT EXISTS criticality_validation JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE rag_chunks ADD COLUMN IF NOT EXISTS related_functions JSONB NOT NULL DEFAULT '[]'::jsonb;
```

**Ne pas executer ces SQL manuellement** : `rag.py` les gere au premier acces.
Et surtout : **ne pas utiliser `docker compose down -v`**, qui effacerait les
volumes de donnees du TP.

## 3. Appliquer la V2 sans reinstaller tout le TP

Depuis le repertoire V1, remplacer `rag.py`, `mcp_server.py`,
`copilot-instructions.txt` et `requirements.txt` par les versions presentes
 dans la V2. Copier les nouveaux `criticality.py` et `tests/test_criticality.py`.
Copier aussi `examples/cpp_demo/criticality.yaml` pour l'exemple ou creer
un fichier `criticality.yaml` specifique dans votre propre depot.

La configuration `.env` existante doit etre **conservee**.
Il n'est pas necessaire de recreer la base ou le conteneur Docker.

Dans PowerShell :

```powershell
cd C:\dev\TP_RAG_CPP_Copilot_Postgres
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Si l'environnement `.venv` n'existe pas encore :

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 4. Demarrer et verifier PostgreSQL

```powershell
docker compose up -d
docker compose ps
.\.venv\Scripts\python.exe rag.py check
```

La base doit etre accessible sur le port configure dans `.env`.

## 5. Tests techniques AVANT reindexation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Attendu : tous les tests se terminent par `OK`.
Les tests du referentiel n'ont pas besoin de PostgreSQL ; la verification
specifique a Clang est ignoree si l'executable n'est pas installe.

## 6. Reindexer le depot et ses niveaux de criticite

```powershell
.\.venv\Scripts\python.exe rag.py index
```

La commande remplace les anciens fragments indexés, mais **pas** la base, ses
comptes ou le volume Docker. L'indexation de l'exemple doit indiquer trois
criticites associees : `Cart::canMove`, `Cart::recharge`, `Cart::batteryLevel`.

L'indexeur signale :
- les regles YAML sans fonction Clang correspondante ;
- les fonctions C++ reconnues mais absentes du YAML ;
- les symboles ambigus (surcharges non distinguables).

En cas d'echec de Clang sur un vrai depot (headers, options, CMake), les
fragments par lignes sont toujours recherches, mais **ils ne peuvent pas
recevoir une criticite exacte**. Corriger alors la configuration de Clang
avant de s'appuyer sur les etiquettes.

## 7. Tester l'etat de l'index et le classement

```powershell
.\.venv\Scripts\python.exe rag.py stats
.\.venv\Scripts\python.exe rag.py audit
```

Pour le petit depot de demonstration, `stats` doit contenir une repartition
incluant au moins une fonction dans chacune des categories `VERT`, `ORANGE`,
`ROUGE`. Les autres fonctions (par exemple `main`) resteront `NON_CLASSEE`.

Une entree dans `yaml_unmatched` de `audit` signifie que la fonction YAML n'a
pas ete retrouvee **sous ce nom, dans ce fichier et avec ce classement**.

Verification SQL directe :

```powershell
docker compose exec postgres psql -U rag -d rag_cpp -c "SELECT symbol, criticality_level, criticality_reason FROM rag_chunks WHERE kind='fonction_clang' ORDER BY symbol;"
```

Pour verifier les validations :

```powershell
docker compose exec postgres psql -U rag -d rag_cpp -c "SELECT symbol, criticality_rules, criticality_validation FROM rag_chunks WHERE criticality_level='ROUGE';"
```

## 8. Tester la recherche vectorielle, sans Copilot

```powershell
.\.venv\Scripts\python.exe rag.py search "Quand le chariot peut-il se deplacer ?" --top-k 10
```

Dans les resultats, verifier qu'une occurrence du symbole `Cart::canMove`
affiche :

```text
CRITICITE: ROUGE (FONCTION_REFERENCEE_DANS_YAML)
MOTIF: Autorise le deplacement du chariot.
REGLES: [...]
VALIDATIONS: [...]
```

Les blocs de type `texte` seront affichees `NON_CLASSEE` avec une portée
`FRAGMENT_MIXTE_A_VERIFIER`, car ils peuvent recouvrir plusieurs fonctions.
Le champ `FONCTIONS DANS LE FRAGMENT` fournit alors des indications
par fonction (dont `ROUGE` si une fonction rouge se trouve dans ces lignes).

## 9. Tester les outils MCP dans GitHub Copilot / CLion

Conserver le serveur MCP `rag-cpp` deja configure. La commande de lancement
reste la meme :

```json
{
  "servers": {
    "rag-cpp": {
      "type": "stdio",
      "command": "C:/dev/TP_RAG_CPP_Copilot_Postgres/.venv/Scripts/python.exe",
      "args": ["C:/dev/TP_RAG_CPP_Copilot_Postgres/mcp_server.py"]
    }
  }
}
```

**Adapter les chemins du JSON au poste.** Redemarrer le serveur MCP dans
Copilot Chat pour charger les nouveaux outils ; si besoin relancer CLion.

En mode Agent, tester les prompts dans cet ordre :

1. `Appelle l'outil etat_rag_cpp. Donne-moi le nombre de fonctions par criticite.`
2. `Appelle lister_criticites_cpp et affiche toutes les fonctions classees avec le code couleur.`
3. `Appelle criticite_fonction_cpp avec Cart::canMove. Quelles verifications sont obligatoires ?`
4. `Appelle rechercher_code_cpp pour expliquer les conditions de deplacement du chariot. Cite src/cart.cpp et les lignes.`

Dans la trace des outils Copilot, il faut **voir l'appel MCP**. Une reponse
contenant seulement un emoji rouge ne prouve pas qu'un outil a ete appele.

## 10. Exercice : modifier seulement YAML, puis reindexer

1. Dans `criticality.yaml`, passer **pour demonstration**
   `Cart::batteryLevel` de `VERT` a `ORANGE` et adapter le motif.
2. Reindexer :

   ```powershell
   .\.venv\Scripts\python.exe rag.py index
   ```

3. Verifier :

   ```powershell
   .\.venv\Scripts\python.exe rag.py audit
   ```

4. Dans Copilot, relancer :
   `Appelle criticite_fonction_cpp avec Cart::batteryLevel et affiche son niveau exact.`
5. Restaurer ensuite `VERT`, puis **reindexer a nouveau**.

Il n'est pas necessaire de redemarrer Docker entre ces essais.

## 11. Diagnostic rapide

| Probleme | Cause probable | Correction |
|---|---|---|
| `criticality.yaml absent` | Le fichier n'est pas dans `CPP_REPO` | Creer le YAML a la racine du depot |
| `No module named yaml` | PyYAML n'est pas installe | Relancer `pip install -r requirements.txt` |
| `YAML sans fonction Clang correspondante` | Fichier, symbole ou Clang incorrect | Comparer le YAML a `rag.py audit` ; verifier Clang |
| Trop de `NON_CLASSEE` | Fonctions non repertoriees, surchargees ou absentes de Clang | Completer YAML et verifier la resolution Clang |
| `postgresql ... refused` | Docker arrete, port ou `.env` incorrect | `docker compose up -d` puis `rag.py check` |
| Copilot ne voit pas les nouveaux outils | Serveur MCP non recharge | Redemarrer le serveur MCP/CLion |
| Ancien niveau apres YAML | Index non regenere | Executer `rag.py index` |

## 12. Regles de prudence

Le YAML est un **referentiel metier**, a versionner et approuver. Son contenu
n'a pas autorite sur les permissions ou la surete d'exploitation du robot.
Une erreur de classement peut provoquer des recommandations dangereuses.
MCP et Copilot ne doivent donc pas pouvoir contourner la revue de code,
les tests, les autorisations GitLab et les politiques CI/CD.

**Confidentialite :** le depot, PostgreSQL et les embeddings sont locaux,
mais les passages restitues a Copilot peuvent etre transmis a son service.
Ne pas faire ce TP sur du code confidentiel sans validation explicite de
la politique d'utilisation de Copilot.
