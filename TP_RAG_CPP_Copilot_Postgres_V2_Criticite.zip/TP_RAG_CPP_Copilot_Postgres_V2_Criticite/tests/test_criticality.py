"""Tests du niveau de criticite sans modele, Docker ni serveur MCP."""
import tempfile
import unittest
from pathlib import Path

from criticality import annotate_chunks, load_catalog, qualified_symbol
from rag import Chunk, collect_chunks


EXAMPLE_YAML = '''
version: 1
functions:
  - file: "src/cart.cpp"
    symbol: "Cart::canMove"
    level: "ROUGE"
    reason: "Fonction critique de deplacement"
    rules: ["Conserver les verifications"]
    validation: ["Tests de securite"]
  - file: "src/cart.cpp"
    symbol: "Cart::recharge"
    level: "ORANGE"
    reason: "Modifie l'etat de charge"
    rules: []
    validation: ["Test de limite"]
  - file: "src/cart.cpp"
    symbol: "Cart::batteryLevel"
    level: "VERT"
    reason: "Lecture d'une mesure"
    rules: []
    validation: []
'''


class TestCriticity(unittest.TestCase):
    def with_yaml(self, yaml_text, action):
        with tempfile.TemporaryDirectory() as folder:
            repo = Path(folder)
            (repo / "criticality.yaml").write_text(yaml_text, encoding="utf-8")
            return action(repo)

    def test_load_three_levels(self):
        catalog = self.with_yaml(EXAMPLE_YAML, load_catalog)
        self.assertEqual(catalog[("src/cart.cpp", "Cart::canMove")].level, "ROUGE")
        self.assertEqual(catalog[("src/cart.cpp", "Cart::recharge")].level, "ORANGE")
        self.assertEqual(catalog[("src/cart.cpp", "Cart::batteryLevel")].level, "VERT")

    def test_qualified_symbol_from_clang_snippet(self):
        self.assertEqual(qualified_symbol("bool Cart::canMove() const { return true; }", "canMove"), "Cart::canMove")
        self.assertEqual(qualified_symbol("void Cart::recharge(int n) { }", "recharge"), "Cart::recharge")
        self.assertEqual(qualified_symbol("int main() { }", "main"), "main")

    def test_exact_classification_only(self):
        catalog = self.with_yaml(EXAMPLE_YAML, load_catalog)
        chunks = [
            Chunk("src/cart.cpp", "texte", "", 1, 30, "mixed text"),
            Chunk("src/cart.cpp", "fonction_clang", "Cart::canMove", 5, 10, "bool Cart::canMove() {}"),
            Chunk("src/cart.cpp", "fonction_clang", "Cart::recharge", 12, 15, "void Cart::recharge() {}"),
            Chunk("src/cart.cpp", "fonction_clang", "clampPercent", 20, 25, "int clampPercent() {}"),
        ]
        rows, matched, ambiguous = annotate_chunks(chunks, catalog)
        self.assertEqual(rows[0]["criticality_level"], "NON_CLASSEE")
        self.assertEqual(rows[0]["criticality_scope"], "FRAGMENT_MIXTE_A_VERIFIER")
        self.assertIn("ROUGE", {f["level"] for f in rows[0]["related_functions"]})
        self.assertEqual(rows[1]["criticality_level"], "ROUGE")
        self.assertEqual(rows[2]["criticality_level"], "ORANGE")
        self.assertEqual(rows[3]["criticality_level"], "NON_CLASSEE")
        self.assertEqual(len(matched), 2)
        self.assertEqual(ambiguous, set())

    def test_ambiguous_symbol_not_automatically_classified(self):
        catalog = self.with_yaml(EXAMPLE_YAML, load_catalog)
        chunks = [
            Chunk("src/cart.cpp", "fonction_clang", "Cart::canMove", 2, 5, "bool Cart::canMove(int) {}"),
            Chunk("src/cart.cpp", "fonction_clang", "Cart::canMove", 7, 9, "bool Cart::canMove(float) {}"),
        ]
        rows, matched, ambiguous = annotate_chunks(chunks, catalog)
        self.assertEqual(len(matched), 0)
        self.assertIn(("src/cart.cpp", "Cart::canMove"), ambiguous)
        self.assertTrue(all(r["criticality_level"] == "NON_CLASSEE" for r in rows))

    def test_reject_duplicate_yaml_key(self):
        text = 'version: 1\nversion: 1\nfunctions: []\n'
        with self.assertRaises(ValueError):
            self.with_yaml(text, load_catalog)

    def test_reject_invalid_path(self):
        text = EXAMPLE_YAML.replace('file: "src/cart.cpp"', 'file: "../private.cpp"', 1)
        with self.assertRaises(ValueError):
            self.with_yaml(text, load_catalog)

    def test_missing_yaml_is_an_error(self):
        with tempfile.TemporaryDirectory() as path:
            with self.assertRaises(FileNotFoundError):
                load_catalog(Path(path))

    def test_real_demo_clang_if_available(self):
        import shutil
        if not shutil.which("clang++"):
            self.skipTest("LLVM/Clang absent")
        repo = Path(__file__).resolve().parents[1] / "examples/cpp_demo"
        chunks, _, count = collect_chunks(repo)
        self.assertGreater(count, 0)
        annotations, matched, ambiguous = annotate_chunks(chunks, load_catalog(repo))
        self.assertIn(("src/cart.cpp", "Cart::canMove"), matched)
        self.assertIn(("src/cart.cpp", "Cart::recharge"), matched)
        self.assertIn(("src/cart.cpp", "Cart::batteryLevel"), matched)
        self.assertFalse(ambiguous)
        red = [a for a in annotations if a["criticality_level"] == "ROUGE"]
        self.assertEqual(len(red), 1)


if __name__ == "__main__":
    unittest.main()
