"""Tests unitaires sans connexion au modele ni a PostgreSQL."""
import tempfile
import unittest
from pathlib import Path

from rag import Chunk, discover_files, line_chunks


class TestRag(unittest.TestCase):
    def test_line_chunks_keeps_line_numbers(self):
        chunks = line_chunks("\n".join(f"L{i}" for i in range(1, 12)), "test.cpp", chunk_lines=5, overlap=1)
        self.assertEqual([(c.start_line, c.end_line) for c in chunks], [(1, 5), (5, 9), (9, 11)])
        self.assertIn("L1", chunks[0].content)
        self.assertIn("L11", chunks[-1].content)

    def test_ignores_secrets_and_build_folder(self):
        with tempfile.TemporaryDirectory() as temp:
            repo = Path(temp)
            (repo / "main.cpp").write_text("int main() {}", encoding="utf-8")
            (repo / ".env").write_text("SECRET=not_for_index", encoding="utf-8")
            (repo / "build").mkdir()
            (repo / "build" / "fake.cpp").write_text("hidden", encoding="utf-8")
            self.assertEqual([p.name for p in discover_files(repo)], ["main.cpp"])

    def test_chunk_id_deterministic(self):
        chunk = Chunk("src/a.cpp", "texte", "", 1, 2, "int x;")
        self.assertEqual(chunk.chunk_id, chunk.chunk_id)
        self.assertEqual(len(chunk.chunk_id), 64)


if __name__ == "__main__":
    unittest.main()
