"""Referentiel metier de criticite, distinct des textes utilises pour les embeddings.

On ne classe comme VERT/ORANGE/ROUGE que les symboles Clang identifies
sans ambiguite. Un bloc de lignes reste MIXTE_A_VERIFIER, avec la liste
indicative des fonctions qu'il recoupe.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import yaml

ALLOWED_LEVELS = {"VERT", "ORANGE", "ROUGE"}


@dataclass(frozen=True)
class CriticalityRule:
    file: str
    symbol: str
    level: str
    reason: str
    rules: tuple[str, ...]
    validation: tuple[str, ...]


class _UniqueKeyLoader(yaml.SafeLoader):
    """Le YAML avec une cle dupliquee ne doit pas ecraser silencieusement une regle."""


def _unique_mapping(loader, node):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=True)
        if key in result:
            raise ValueError(f"Cle YAML dupliquee : {key}")
        result[key] = loader.construct_object(value_node, deep=True)
    return result


_UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _unique_mapping
)


def _strings(value: object, name: str) -> tuple[str, ...]:
    if not isinstance(value, list) or any(not isinstance(v, str) or not v.strip() for v in value):
        raise ValueError(f"{name} doit etre une liste de chaines non vides")
    return tuple(v.strip() for v in value)


def load_catalog(repo: Path) -> dict[tuple[str, str], CriticalityRule]:
    path = repo / "criticality.yaml"
    if not path.is_file():
        raise FileNotFoundError(
            f"{path} absent. Creer criticality.yaml a la racine du depot CPP_REPO."
        )
    if path.is_symlink():
        raise ValueError("Le referentiel criticality.yaml ne doit pas etre un lien symbolique")
    if path.stat().st_size > 200_000:
        raise ValueError("criticality.yaml est trop volumineux (limite 200 Ko)")
    try:
        document = yaml.load(path.read_text(encoding="utf-8-sig"), Loader=_UniqueKeyLoader)
    except yaml.YAMLError as exc:
        raise ValueError(f"YAML invalide: {exc}") from exc
    if not isinstance(document, dict) or document.get("version") != 1:
        raise ValueError("criticality.yaml doit contenir version: 1")
    rows = document.get("functions")
    if not isinstance(rows, list):
        raise ValueError("criticality.yaml doit contenir functions: [ ... ]")
    catalog: dict[tuple[str, str], CriticalityRule] = {}
    for i, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            raise ValueError(f"functions[{i}] doit etre un objet")
        file = row.get("file")
        symbol = row.get("symbol")
        level = row.get("level")
        reason = row.get("reason")
        if not isinstance(file, str) or not file or "\\" in file or file.startswith("/"):
            raise ValueError(f"functions[{i}].file doit etre un chemin relatif POSIX")
        if ":" in file or any(p in {".", "..", ""} for p in file.split("/")):
            raise ValueError(f"functions[{i}].file contient un chemin dangereux ou ambigu")
        if not isinstance(symbol, str) or not symbol.strip():
            raise ValueError(f"functions[{i}].symbol manquant")
        if level not in ALLOWED_LEVELS:
            raise ValueError(f"functions[{i}].level doit etre VERT, ORANGE ou ROUGE")
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError(f"functions[{i}].reason est obligatoire")
        rules = _strings(row.get("rules", []), f"functions[{i}].rules")
        validation = _strings(row.get("validation", []), f"functions[{i}].validation")
        if level == "ROUGE" and (not rules or not validation):
            raise ValueError(f"functions[{i}] : ROUGE exige rules et validation")
        key = (file, symbol.strip())
        if key in catalog:
            raise ValueError(f"Criticite dupliquee pour {key[0]} / {key[1]}")
        catalog[key] = CriticalityRule(file, symbol.strip(), level, reason.strip(), rules, validation)
    return catalog


def qualified_symbol(snippet: str, fallback: str) -> str:
    """Recupere 'Cart::canMove' d'une definition C++ issue de l'AST Clang.

    Ne devine pas un namespace implicite ni les surcharges : ces cas restent
    a auditer. Le prefixe provient exclusivement de la signature du snippet.
    """
    header = snippet.split("{", 1)[0]
    token = re.escape(fallback)
    pattern = rf"(?<![\w:])((?:[A-Za-z_]\w*::)*{token})\s*\("
    matches = re.findall(pattern, header)
    return matches[-1] if matches else fallback


def annotate_chunks(chunks, catalog):
    """Produit une annotation pour chaque Chunk sans modifier ses embeddings.

    Retourne (annotations, matched_keys, ambiguous_keys).
    """
    from collections import Counter

    function_chunks = [c for c in chunks if c.kind == "fonction_clang"]
    counts = Counter((c.file_path, c.symbol) for c in function_chunks)
    ambiguous_keys = {key for key, n in counts.items() if n > 1}
    matched = set()
    annotations = []
    by_file = {}
    for c in function_chunks:
        by_file.setdefault(c.file_path, []).append(c)

    for c in chunks:
        related = []
        if c.kind == "fonction_clang":
            key = (c.file_path, c.symbol)
            rule = catalog.get(key) if key not in ambiguous_keys else None
            if rule:
                matched.add(key)
                annotations.append({
                    "criticality_level": rule.level,
                    "criticality_scope": "FONCTION_REFERENCEE_DANS_YAML",
                    "criticality_reason": rule.reason,
                    "criticality_rules": list(rule.rules),
                    "criticality_validation": list(rule.validation),
                    "related_functions": [],
                })
            else:
                detail = "Symbole Clang ambigu (surcharge ou doublon)" if key in ambiguous_keys else "Fonction absente du referentiel"
                annotations.append({
                    "criticality_level": "NON_CLASSEE",
                    "criticality_scope": "FONCTION_SANS_CLASSEMENT",
                    "criticality_reason": detail,
                    "criticality_rules": [],
                    "criticality_validation": [],
                    "related_functions": [],
                })
        else:
            for function in by_file.get(c.file_path, []):
                if function.start_line <= c.end_line and function.end_line >= c.start_line:
                    key = (function.file_path, function.symbol)
                    rule = catalog.get(key) if key not in ambiguous_keys else None
                    related.append({
                        "symbol": function.symbol,
                        "start_line": function.start_line,
                        "end_line": function.end_line,
                        "level": rule.level if rule else "NON_CLASSEE",
                    })
            annotations.append({
                "criticality_level": "NON_CLASSEE",
                "criticality_scope": "FRAGMENT_MIXTE_A_VERIFIER",
                "criticality_reason": "Un bloc de lignes peut contenir plusieurs fonctions; voir related_functions.",
                "criticality_rules": [],
                "criticality_validation": [],
                "related_functions": related,
            })
    return annotations, matched, ambiguous_keys
