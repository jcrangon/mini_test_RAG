# TP RAG C++ / PostgreSQL / Copilot — V2 Criticité

## Objectif

Cette version complète la V1 du TP en ajoutant un référentiel de criticité **VERT / ORANGE / ROUGE**, stocké dans `criticality.yaml` à la racine du dépôt C++ analysé. Une fonction sans classement explicite reste `NON_CLASSEE`. Le serveur MCP restitue le classement et les contraintes à GitHub Copilot dans CLion.

**Aucune réinstallation de PostgreSQL ni remise à zéro du volume Docker n’est nécessaire.** La migration ajoute automatiquement des colonnes à `rag_chunks`. Le modèle d'embeddings local reste identique ; aucun Ollama.

## À lire en premier

➡️ **[GUIDE_AJOUT_CRITICITE.md](GUIDE_AJOUT_CRITICITE.md)** : procédure exhaustive PowerShell pour la migration, l’indexation, les tests SQL et les tests MCP dans Copilot.

Le script `INSTALLER_MISE_A_JOUR.ps1` permet de copier les fichiers V2 dans une copie existante de la V1 tout en protégeant les fichiers de configuration et les référentiels YAML déjà présents. Un mode de mise à jour manuelle est aussi décrit dans le guide.

## Fichiers nouveaux ou modifiés

| Fichier | Utilité |
|---|---|
| `criticality.py` | Validation stricte du YAML et association Clang / niveau métier |
| `rag.py` | Migration de schéma, indexation des métadonnées, statistiques, audit et recherche enrichie |
| `mcp_server.py` | Quatre outils MCP, avec codes couleurs et détails des contraintes |
| `requirements.txt` | Ajout de PyYAML |
| `copilot-instructions.txt` | Règles de réponse graduées selon criticité |
| `examples/cpp_demo/criticality.yaml` | Exemple versionné, trois niveaux |
| `tests/test_criticality.py` | Contrôle des validations, cas ambigus et extraction Clang |
| `INSTALLER_MISE_A_JOUR.ps1` | Installation non destructive dans une V1 existante |

## Vérifications rapides

Depuis la racine du TP (après mise à jour, avec `.venv` existant) :

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
docker compose up -d
.\.venv\Scripts\python.exe rag.py check
.\.venv\Scripts\python.exe rag.py index
.\.venv\Scripts\python.exe rag.py stats
.\.venv\Scripts\python.exe rag.py audit
.\.venv\Scripts\python.exe rag.py search "conditions pour autoriser le déplacement" --top-k 10
```

Puis, dans Copilot **Agent**, appeler `etat_rag_cpp`, `lister_criticites_cpp`, `criticite_fonction_cpp("Cart::canMove")` et `rechercher_code_cpp(...)`, en **vérifiant les traces d'appels MCP**.

## Confidentialité et limites

Ce RAG est un outil d'assistance et ne certifie aucune sûreté de fonctionnement. Une critique YAML erronée ou une analyse Clang incomplète ne doit pas être présentée comme validée. Les extraits transmis à Copilot peuvent quitter le poste vers le service Copilot selon le contrat et la politique de l'organisation. Ne jamais tester sur du code confidentiel sans autorisation.
