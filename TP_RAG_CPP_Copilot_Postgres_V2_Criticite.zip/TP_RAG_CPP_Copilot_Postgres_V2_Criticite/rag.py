"""TP RAG C++ : indexation locale Clang -> embeddings -> PostgreSQL/pgvector.

Commandes :
    python rag.py check
    python rag.py index
    python rag.py stats
    python rag.py search "Quand le chariot peut-il se deplacer ?"

Le modele d'embeddings s'execute localement. Copilot n'est pas utilise
pour indexer : il interroge ensuite le serveur MCP en lecture seule.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from dotenv import load_dotenv
from criticality import annotate_chunks, load_catalog, qualified_symbol

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

# Ne jamais indexer les secrets, les depots internes a Git, les builds, etc.
ALLOWED_SUFFIXES = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".md", ".txt", ".cmake"}
IGNORED_DIRS = {".git", ".venv", ".idea", ".vscode", "build", "cmake-build-debug", "cmake-build-release", "dist", "node_modules", "__pycache__", "vendor", "third_party", "third-party", "generated"}
MAX_FILE_SIZE = 300_000
EMBED_DIMENSION = 384
AST_KINDS = {"FunctionDecl", "CXXMethodDecl", "CXXConstructorDecl", "CXXDestructorDecl", "CXXConversionDecl"}


def repository_path() -> Path:
    configured = os.getenv("CPP_REPO", "./examples/cpp_demo")
    path = Path(configured).expanduser()
    return (path if path.is_absolute() else BASE_DIR / path).resolve()


def pg_dsn() -> str:
    return os.getenv("POSTGRES_DSN", "postgresql://rag:rag_demo_pwd@127.0.0.1:5433/rag_cpp")


@dataclass(frozen=True)
class Chunk:
    file_path: str
    kind: str
    symbol: str
    start_line: int
    end_line: int
    content: str

    @property
    def chunk_id(self) -> str:
        """Identifiant stable pour une reindexation reproductible."""
        value = f"{self.file_path}:{self.kind}:{self.symbol}:{self.start_line}:{self.end_line}:{self.content}"
        return hashlib.sha256(value.encode("utf-8")).hexdigest()

    def for_embedding(self) -> str:
        return f"Fichier C++: {self.file_path}\nType: {self.kind}\nSymbole: {self.symbol}\n{self.content}"


def discover_files(repo: Path) -> list[Path]:
    if not repo.is_dir():
        raise FileNotFoundError(f"Depot introuvable: {repo}. Corriger CPP_REPO dans .env")
    result = []
    for path in repo.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(repo)
        if any(part.lower() in IGNORED_DIRS for part in relative.parts[:-1]):
            continue
        if path.name != "CMakeLists.txt" and path.suffix.lower() not in ALLOWED_SUFFIXES:
            continue
        if path.stat().st_size > MAX_FILE_SIZE:
            continue
        result.append(path)
    return sorted(result)


def line_chunks(content: str, file_path: str, chunk_lines: int = 50, overlap: int = 10) -> list[Chunk]:
    """Decoupage robuste, utilise meme quand Clang ne sait pas compiler le fichier."""
    if chunk_lines <= overlap or overlap < 0:
        raise ValueError("chunk_lines doit etre strictement superieur a overlap")
    lines = content.splitlines()
    result = []
    for start in range(0, len(lines), chunk_lines - overlap):
        end = min(start + chunk_lines, len(lines))
        block = "\n".join(lines[start:end]).strip()
        if block:
            result.append(Chunk(file_path, "texte", "", start + 1, end, block))
        if end == len(lines):
            break
    return result


def _ast_functions(repo: Path, path: Path, content: str) -> list[Chunk]:
    """Extraire des definitions de fonctions via l'AST JSON de Clang.

    En cas d'absence de Clang, d'headers manquants ou de configuration CMake
    complexe, la recherche continue a fonctionner grace au decoupage par lignes.
    """
    if path.suffix.lower() not in {".c", ".cc", ".cpp", ".cxx"}:
        return []
    clang = shutil.which(os.getenv("CLANG_BIN", "clang++"))
    if clang is None:
        return []
    # Un AST complet avec <iostream>/<algorithm> peut depasser des dizaines de Mo.
    # Clang permet de filtrer l'AST par nom de symbole : on cible d'abord
    # les noms de classes figurant dans les definitions "Classe::methode".
    class_names = re.findall(r"\b([A-Za-z_]\w*)::[~]?[A-Za-z_]\w*\s*\(", content)
    global_names = re.findall(
        r"(?m)^[\w \t:*&<>~,]+?\b([A-Za-z_]\w*)\s*\([^;{}]*\)\s*(?:const\s*)?\{",
        content,
    )
    filters = list(dict.fromkeys(class_names + global_names))[:3]
    if not filters:
        return []

    roots: list[dict] = []
    decoder = json.JSONDecoder()
    for name_filter in filters:
        command = [clang, "-std=c++17", "-fsyntax-only", "-Wno-everything",
                   "-I", str(repo), "-I", str(repo / "include"),
                   "-Xclang", "-ast-dump=json",
                   "-Xclang", f"-ast-dump-filter={name_filter}", str(path)]
        try:
            completed = subprocess.run(command, capture_output=True, text=True,
                                       encoding="utf-8", errors="replace", timeout=30, check=False)
            if completed.returncode != 0 or not completed.stdout.strip():
                continue
            if len(completed.stdout) > 8_000_000:
                continue
            # L'option ast-dump-filter rend plusieurs objets JSON consecutifs.
            raw = completed.stdout
            cursor = 0
            while cursor < len(raw):
                while cursor < len(raw) and raw[cursor].isspace():
                    cursor += 1
                if cursor >= len(raw):
                    break
                node, cursor = decoder.raw_decode(raw, cursor)
                roots.append(node)
        except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError):
            continue

    data = content.encode("utf-8")
    relative = path.relative_to(repo).as_posix()
    found: list[Chunk] = []
    seen: set[tuple[int, int]] = set()
    todo = list(roots)
    while todo:
        node = todo.pop()
        if not isinstance(node, dict):
            continue
        todo.extend(node.get("inner", []))
        if node.get("kind") not in AST_KINDS:
            continue
        # Ignorer les prototypes : une definition possede un corps CompoundStmt.
        children = node.get("inner", [])
        if not any(isinstance(child, dict) and child.get("kind") in {"CompoundStmt", "CXXTryStmt"}
                   for child in children):
            continue
        loc = node.get("loc", {})
        # Evite autant que possible les declarations dans les headers inclus.
        if loc.get("includedFrom"):
            continue
        declared_file = loc.get("file")
        if declared_file and Path(declared_file).resolve() != path.resolve():
            continue
        span = node.get("range", {})
        begin = span.get("begin", {}).get("offset")
        end_loc = span.get("end", {})
        end = end_loc.get("offset")
        token_len = end_loc.get("tokLen", 1)
        if not isinstance(begin, int) or not isinstance(end, int):
            continue
        end += token_len if isinstance(token_len, int) else 1
        if not (0 <= begin < end <= len(data)) or (begin, end) in seen:
            continue
        snippet = data[begin:end].decode("utf-8", errors="replace").strip()
        name = node.get("name") or "fonction_anonyme"
        if len(snippet) < 15 or len(snippet) > 12_000 or str(name) not in snippet:
            continue
        seen.add((begin, end))
        start_line = data[:begin].count(b"\n") + 1
        end_line = data[:end].count(b"\n") + 1
        found.append(Chunk(relative, "fonction_clang", qualified_symbol(snippet, str(name)), start_line, end_line, snippet))
    return sorted(found, key=lambda x: (x.file_path, x.start_line))


def collect_chunks(repo: Path) -> tuple[list[Chunk], int, int]:
    chunks = []
    ast_count = 0
    paths = discover_files(repo)
    for path in paths:
        content = path.read_text(encoding="utf-8-sig", errors="replace")
        relative = path.relative_to(repo).as_posix()
        chunks.extend(line_chunks(content, relative))
        ast = _ast_functions(repo, path, content)
        chunks.extend(ast)
        ast_count += len(ast)
    return chunks, len(paths), ast_count


def connect_db():
    """Connexions psycopg avec l'adaptateur pgvector actif."""
    import psycopg
    from pgvector.psycopg import register_vector

    conn = psycopg.connect(pg_dsn())
    conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
    register_vector(conn)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS rag_chunks (
            id TEXT PRIMARY KEY,
            file_path TEXT NOT NULL,
            kind TEXT NOT NULL,
            symbol TEXT NOT NULL,
            start_line INTEGER NOT NULL,
            end_line INTEGER NOT NULL,
            content TEXT NOT NULL,
            embedding vector(384) NOT NULL,
            criticality_level TEXT NOT NULL DEFAULT 'NON_CLASSEE',
            criticality_scope TEXT NOT NULL DEFAULT 'NON_CLASSEE',
            criticality_reason TEXT NOT NULL DEFAULT '',
            criticality_rules JSONB NOT NULL DEFAULT '[]'::jsonb,
            criticality_validation JSONB NOT NULL DEFAULT '[]'::jsonb,
            related_functions JSONB NOT NULL DEFAULT '[]'::jsonb
        )
    """)
    # Migration non destructive des anciennes bases deja remplies par le TP V1.
    for column, ddl in (
        ("criticality_level", "TEXT NOT NULL DEFAULT 'NON_CLASSEE'"),
        ("criticality_scope", "TEXT NOT NULL DEFAULT 'NON_CLASSEE'"),
        ("criticality_reason", "TEXT NOT NULL DEFAULT ''"),
        ("criticality_rules", "JSONB NOT NULL DEFAULT '[]'::jsonb"),
        ("criticality_validation", "JSONB NOT NULL DEFAULT '[]'::jsonb"),
        ("related_functions", "JSONB NOT NULL DEFAULT '[]'::jsonb"),
    ):
        conn.execute(f"ALTER TABLE rag_chunks ADD COLUMN IF NOT EXISTS {column} {ddl}")
    conn.execute("""
        CREATE INDEX IF NOT EXISTS rag_chunks_embedding_hnsw
        ON rag_chunks USING hnsw (embedding vector_cosine_ops)
    """)
    conn.commit()
    return conn


def embedding_model():
    """Charge le modele en local; premier lancement = telechargement du modele."""
    from sentence_transformers import SentenceTransformer

    model = SentenceTransformer(os.getenv("EMBED_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"), device="cpu")
    if model.get_sentence_embedding_dimension() != EMBED_DIMENSION:
        raise ValueError(f"Le modele doit retourner {EMBED_DIMENSION} dimensions")
    return model


def index_repository() -> None:
    repo = repository_path()
    catalog = load_catalog(repo)
    chunks, count, ast_count = collect_chunks(repo)
    if not chunks:
        raise RuntimeError("Aucun fichier indexable dans le depot")
    annotations, matched, ambiguous = annotate_chunks(chunks, catalog)
    unmatched = sorted(set(catalog) - matched)
    print(f"Depot: {repo}")
    print(f"Criticites: {len(matched)} associees | {len(unmatched)} non associees | {len(ambiguous)} symboles ambigus")
    for file, symbol in unmatched:
        print(f"ATTENTION : YAML sans fonction Clang correspondante : {file} / {symbol}")
    for file, symbol in sorted(ambiguous):
        print(f"ATTENTION : fonction ambigue, NON_CLASSEE : {file} / {symbol}")
    print(f"Fichiers: {count} | fragments: {len(chunks)} | fonctions via Clang: {ast_count}")
    print("Generation locale des embeddings...")
    model = embedding_model()
    vectors = model.encode([c.for_embedding() for c in chunks],
                           batch_size=16, show_progress_bar=True,
                           normalize_embeddings=True, convert_to_numpy=True)
    from psycopg.types.json import Jsonb
    with connect_db() as conn:
        # Transaction : la base n'est pas videe en cas d'erreur d'insertion.
        with conn.transaction():
            conn.execute("DELETE FROM rag_chunks")
            with conn.cursor() as cur:
                cur.executemany("""
                    INSERT INTO rag_chunks
                    (id, file_path, kind, symbol, start_line, end_line, content, embedding,
                     criticality_level, criticality_scope, criticality_reason,
                     criticality_rules, criticality_validation, related_functions)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s,
                            %s, %s, %s, %s, %s, %s)
                """, [(
                    c.chunk_id, c.file_path, c.kind, c.symbol,
                    c.start_line, c.end_line, c.content, vector,
                    a["criticality_level"], a["criticality_scope"], a["criticality_reason"],
                    Jsonb(a["criticality_rules"]), Jsonb(a["criticality_validation"]),
                    Jsonb(a["related_functions"]),
                ) for c, vector, a in zip(chunks, vectors, annotations)])
    print(f"Indexation terminee : {len(chunks)} fragments dans PostgreSQL.")


def search(query: str, top_k: int = 5) -> list[dict]:
    """Recherche vectorielle pure, sans appel a Copilot."""
    top_k = max(1, min(int(top_k), 10))
    vector = embedding_model().encode(query, normalize_embeddings=True, convert_to_numpy=True)
    with connect_db() as conn:
        rows = conn.execute("""
            SELECT file_path, kind, symbol, start_line, end_line, content,
                   1 - (embedding <=> %s) AS similarity,
                   criticality_level, criticality_scope, criticality_reason,
                   criticality_rules, criticality_validation, related_functions
            FROM rag_chunks
            ORDER BY embedding <=> %s
            LIMIT %s
        """, (vector, vector, top_k)).fetchall()
    return [dict(file_path=row[0], kind=row[1], symbol=row[2],
                 start_line=row[3], end_line=row[4], content=row[5],
                 similarity=float(row[6]), criticality_level=row[7],
                 criticality_scope=row[8], criticality_reason=row[9],
                 criticality_rules=row[10], criticality_validation=row[11],
                 related_functions=row[12]) for row in rows]


def stats() -> dict:
    with connect_db() as conn:
        row = conn.execute("""
            SELECT COUNT(*), COUNT(DISTINCT file_path),
                   COUNT(*) FILTER (WHERE kind = 'fonction_clang')
            FROM rag_chunks
        """).fetchone()
        classified_rows = conn.execute("""
            SELECT criticality_level, COUNT(*)
            FROM rag_chunks WHERE kind='fonction_clang'
            GROUP BY criticality_level ORDER BY criticality_level
        """).fetchall()
    return {"fragments": row[0], "fichiers": row[1], "fonctions_clang": row[2],
            "fonctions_par_criticite": dict(classified_rows),
            "depot": str(repository_path())}


def list_criticalities() -> list[dict]:
    """Liste les fonctions classees, y compris NON_CLASSEE, sans recalculer les vecteurs."""
    with connect_db() as conn:
        rows = conn.execute("""
            SELECT file_path, symbol, start_line, end_line,
                   criticality_level, criticality_reason,
                   criticality_rules, criticality_validation
            FROM rag_chunks
            WHERE kind = 'fonction_clang'
            ORDER BY file_path, start_line
        """).fetchall()
    return [dict(file_path=r[0], symbol=r[1], start_line=r[2], end_line=r[3],
                 level=r[4], reason=r[5], rules=r[6], validation=r[7]) for r in rows]


def audit_criticalities() -> dict:
    """Compare les entrees YAML aux vraies fonctions identifiees par Clang."""
    catalog = load_catalog(repository_path())
    functions = list_criticalities()
    indexed = {(row['file_path'], row['symbol']) for row in functions if row['level'] != 'NON_CLASSEE'}
    return {
        'functions': functions,
        'yaml_unmatched': [{'file': file, 'symbol': symbol} for file, symbol in sorted(set(catalog) - indexed)],
        'note': 'Les fonctions non trouvees par Clang ne peuvent pas etre certifiees par ce RAG.'
    }


def check() -> None:
    repo = repository_path()
    clang = shutil.which(os.getenv("CLANG_BIN", "clang++"))
    print(f"Depot: {repo} | existe: {repo.is_dir()}")
    print(f"Clang: {clang or 'NON TROUVE (installer LLVM et ajouter clang++ au PATH)'}")
    if repo.is_dir():
        print(f"Fichiers autorises: {len(discover_files(repo))}")
    try:
        print(f"PostgreSQL: OK | {stats()}")
    except Exception as exc:
        print(f"PostgreSQL: NON DISPONIBLE | {exc}")
        raise SystemExit(1) from exc
    if not repo.is_dir():
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser(description="RAG pedagogique pour depot C++")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("check", "index", "stats", "audit"):
        sub.add_parser(name)
    p_search = sub.add_parser("search")
    p_search.add_argument("question")
    p_search.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()

    if args.command == "check":
        check()
    elif args.command == "index":
        index_repository()
    elif args.command == "stats":
        print(json.dumps(stats(), ensure_ascii=False, indent=2))
    elif args.command == "audit":
        print(json.dumps(audit_criticalities(), ensure_ascii=False, indent=2))
    elif args.command == "search":
        for rank, item in enumerate(search(args.question, args.top_k), 1):
            print(f"\n[{rank}] {item['file_path']}:{item['start_line']}-{item['end_line']} "
                  f"| {item['kind']} {item['symbol']} | similarite={item['similarity']:.3f}")
            print(f"CRITICITE: {item['criticality_level']} ({item['criticality_scope']})")
            print(f"MOTIF: {item['criticality_reason']}")
            if item['related_functions']:
                print(f"FONCTIONS DANS LE FRAGMENT: {json.dumps(item['related_functions'], ensure_ascii=False)}")
            if item['criticality_rules']:
                print(f"REGLES: {json.dumps(item['criticality_rules'], ensure_ascii=False)}")
            if item['criticality_validation']:
                print(f"VALIDATIONS: {json.dumps(item['criticality_validation'], ensure_ascii=False)}")
            print(item["content"][:1400])


if __name__ == "__main__":
    try:
        main()
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"ERREUR : {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
