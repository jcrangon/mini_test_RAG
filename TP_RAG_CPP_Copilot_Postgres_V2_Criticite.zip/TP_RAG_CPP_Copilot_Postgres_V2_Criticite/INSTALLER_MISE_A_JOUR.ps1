﻿<#
  Installer la V2 depuis son dossier décompressé vers une installation V1 existante.
  Usage : .\INSTALLER_MISE_A_JOUR.ps1 -CibleV1 "C:\dev\TP_RAG_CPP_Copilot_Postgres"
  L'installation ne modifie ni .env ni la base PostgreSQL.
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$CibleV1
)
$ErrorActionPreference = "Stop"
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = (Resolve-Path -LiteralPath $CibleV1).Path
if (-not (Test-Path -LiteralPath (Join-Path $target "rag.py")) -or
    -not (Test-Path -LiteralPath (Join-Path $target "mcp_server.py"))) {
    throw "La cible ne contient pas rag.py et mcp_server.py : $target"
}
if ($source -eq $target) { throw "Source et cible identiques. Preciser une installation V1 distincte." }
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $target "sauvegarde_avant_V2_$stamp"
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$replace = @(
    "rag.py", "mcp_server.py", "requirements.txt",
    "copilot-instructions.txt", "README.md", "criticality.py",
    "tests/test_criticality.py", "GUIDE_AJOUT_CRITICITE.md"
)
foreach ($relative in $replace) {
    $s = Join-Path $source $relative
    $t = Join-Path $target $relative
    $b = Join-Path $backup $relative
    if (-not (Test-Path -LiteralPath $s)) { throw "Fichier source manquant : $s" }
    if (Test-Path -LiteralPath $t) {
        New-Item -ItemType Directory -Path (Split-Path $b -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $t -Destination $b -Force
    }
    New-Item -ItemType Directory -Path (Split-Path $t -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $s -Destination $t -Force
    Write-Host "Mis a jour : $relative"
}
# YAML utilisateur : ne jamais écraser un référentiel métier déjà édité.
$yamlRelative = "examples/cpp_demo/criticality.yaml"
$yamlSrc = Join-Path $source $yamlRelative
$yamlDest = Join-Path $target $yamlRelative
if (-not (Test-Path -LiteralPath $yamlDest)) {
    New-Item -ItemType Directory -Path (Split-Path $yamlDest -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $yamlSrc -Destination $yamlDest
    Write-Host "Ajoute : $yamlRelative"
} else {
    Write-Host "Conserve sans changement : $yamlRelative"
}
Write-Host ""
Write-Host "Mise a jour des fichiers terminee. Sauvegardes : $backup" -ForegroundColor Green
Write-Host "Configuration .env, Docker, depot CPP_REPO et base de donnees non modifies."
Write-Host "Dans la cible : pip install -r requirements.txt ; python rag.py index ; python rag.py audit"
