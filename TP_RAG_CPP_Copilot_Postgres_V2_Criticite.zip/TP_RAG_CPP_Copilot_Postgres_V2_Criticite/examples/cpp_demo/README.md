# Petit depot C++ d'entrainement

Ce depot pedagogique contient `Cart`, une classe de gestion simplifiee du mouvement.

- Une batterie inferieure a 20 % empeche le mouvement.
- Les freins doivent etre liberes.
- Un obstacle detecte interdit le mouvement.
- Le niveau de batterie est borne entre 0 et 100.

Le code est fictif et ne doit pas etre utilise pour piloter un equipement reel.
