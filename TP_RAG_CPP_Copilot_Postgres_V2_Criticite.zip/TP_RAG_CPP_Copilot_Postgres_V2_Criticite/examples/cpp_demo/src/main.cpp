#include "cart.hpp"

int main() {
    Cart cart(42);
    bool move_is_authorized = cart.canMove(true, false);
    cart.recharge(10);
    return move_is_authorized ? 0 : 1;
}
