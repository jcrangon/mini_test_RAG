#include "cart.hpp"

// Helper C++ autonome : aucun header standard externe n'est necessaire.
static int clampPercent(int value) {
    if (value < 0) return 0;
    if (value > 100) return 100;
    return value;
}

Cart::Cart(int battery_percent)
    : battery_percent_(clampPercent(battery_percent)) {}

bool Cart::canMove(bool brakes_released, bool obstacle_detected) const {
    // Regle metier pedagogique : pas de deplacement en dessous de 20 %.
    return battery_percent_ >= 20 && brakes_released && !obstacle_detected;
}

void Cart::recharge(int amount) {
    if (amount > 0) {
        battery_percent_ = clampPercent(battery_percent_ + amount);
    }
}

int Cart::batteryLevel() const {
    return battery_percent_;
}
