#pragma once

class Cart {
public:
    explicit Cart(int battery_percent);
    bool canMove(bool brakes_released, bool obstacle_detected) const;
    void recharge(int amount);
    int batteryLevel() const;
private:
    int battery_percent_;
};
